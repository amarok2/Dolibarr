# This theme should be compatible with latest version of Dolibarr soon !
Please come back later !

# Theme Amarok2 for Dolibarr 6.x
This is a theme i create some years ago, and try to improve and make it compatible with Dolibarr version 6.

## Contributors
Nicolas (nicolas@wapp.fr)<br>
Philazerty<br>

## The icons are from Free FatCow-Farm Fresh Icons
http://www.fatcow.com/free-icons
<br>
Here is their licence :
<br>
These icons are licensed under a Creative Commons Attribution 3.0 License.
<br>
http://creativecommons.org/licenses/by/3.0/us/ if you do not know how to link
back to FatCow's website, you can ask https://plus.google.com/+MarcisGasuns
<br>
Biggest icon set drawn by a single designer (in pixel smooth style) worldwide.


Thanks for coming here !

Nicolas

