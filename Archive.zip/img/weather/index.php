Directory access denied.
